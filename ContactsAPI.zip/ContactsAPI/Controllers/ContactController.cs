﻿using ContactsAPI.ActionFilters;
using ContactsAPI.Models;
using ContactsAPI.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ContactsAPI.Controllers
{
    [RoutePrefix("Contact")]
    public class ContactController : ApiController
    {
        private IContactRepository repository;

        public ContactController(IContactRepository contactRepository)
        {
            repository = contactRepository;
        }

        [HttpGet]
        public IHttpActionResult Get()
        {
            IEnumerable<Contact> result = repository.GetAll();
            return Ok(result);
        }

        [HttpGet]
        public IHttpActionResult Get(int id)
        {
            Contact result = repository.Get(id);

            if (result == null)
            {
                return NotFound();
            }

            return Ok(result);
        }

        [ValidateModel]
        [HttpPost]
        public IHttpActionResult Post([FromBody]Contact contact)
        {
            Contact result = repository.Post(contact);

            if(result == null)
            {
                return InternalServerError();
            }

            return Created("", result);
        }

        [ValidateModel]
        [HttpPut]
        public IHttpActionResult Put(int id, [FromBody]Contact contact)
        {
            Contact result = repository.Put(id, contact);

            if (result == null)
            {
                return InternalServerError();
            }

            return Ok("Updated");
        }

        [HttpDelete]
        public IHttpActionResult Delete(int id)
        {
            bool result = repository.Delete(id);

            if (result == false)
            {
                return InternalServerError();
            }

            return Ok("Deleted");
        }
    }
}
