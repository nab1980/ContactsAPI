﻿using System;
using System.Collections.Generic;
using System.Linq;
using ContactsAPI.Models;

namespace ContactsAPI.Repository
{
    public class ContactRepository : IContactRepository
    {
        ContactDBContext dbContext = new ContactDBContext();

        /// <summary>
        /// Get List of all contacts
        /// </summary>
        /// <returns>List of Contacts</returns>
        public IEnumerable<Contact> GetAll()
        {
            return dbContext.Contacts.ToList();
        }

        /// <summary>
        /// Get contact by id
        /// </summary>
        /// <param name="id">Contact Id</param>
        /// <returns></returns>
        public Contact Get(int id)
        {
            return dbContext.Contacts.FirstOrDefault<Contact>(x => x.Id == id);
        }

        /// <summary>
        /// Create new contact
        /// </summary>
        /// <param name="contact">Conatct Details</param>
        /// <returns></returns>
        public Contact Post(Contact contact)
        {
            Contact result = dbContext.Contacts.Add(contact);
            dbContext.SaveChanges();
            return result;
        }
            
        /// <summary>
        /// Update contact details
        /// </summary>
        /// <param name="id">Contact Id</param>
        /// <param name="contact">Updated contact details</param>
        /// <returns></returns>
        public Contact Put(int id, Contact contact)
        {
            Contact oldContact = dbContext.Contacts.FirstOrDefault<Contact>(x => x.Id == id);

            if(oldContact != null)
            {
                oldContact.FirstName = contact.FirstName;
                oldContact.LastName = contact.LastName;
                oldContact.Email = contact.Email;
                oldContact.PhoneNumber = contact.PhoneNumber;
                oldContact.Status = contact.Status;
                dbContext.SaveChanges();
            }

            return oldContact;
        }

        /// <summary>
        /// Delete Contact from database
        /// </summary>
        /// <param name="id">Contact Id</param>
        /// <returns>Boolean</returns>
        public bool Delete(int id)
        {
            Contact contact = dbContext.Contacts.FirstOrDefault<Contact>(x => x.Id == id);
            Contact oldContact = dbContext.Contacts.Remove(contact);
            dbContext.SaveChanges();
            return true;
        }
    }
}