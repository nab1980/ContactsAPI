﻿using ContactsAPI.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace ContactsAPI.Repository
{
    public class ContactDBContext : DbContext
    {
        public ContactDBContext() : base("ContactDB")
        { } 

        public DbSet<Contact> Contacts { get; set; }
    }
}