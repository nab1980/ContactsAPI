using System.Web.Http;
using Unity;
using Unity.WebApi;
using ContactsAPI.Repository;

namespace ContactsAPI
{
	public static class UnityConfig
	{
		public static void RegisterComponents()
		{
			var container = new UnityContainer();
			container.RegisterType<IContactRepository, ContactRepository>();
			
			GlobalConfiguration.Configuration.DependencyResolver = new UnityDependencyResolver(container);

		}
	}
}