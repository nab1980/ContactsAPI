﻿using System.Net;
using System.Net.Http;
using System.Web.Http.Filters;

namespace ContactsAPI.ActionFilters
{
    public class ContactExceptionFilter : ExceptionFilterAttribute
    {
        public override void OnException(HttpActionExecutedContext actionExecutedContext)
        {
            // We can log this exception message to the file or database here.  

            var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
            {
                Content = new StringContent("An unhandled exception was thrown by service."),
                ReasonPhrase = "Internal Server Error. Please Contact your Administrator."
            };
            actionExecutedContext.Response = response;
        }
    }
}