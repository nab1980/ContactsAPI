﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ContactsAPI.Tests
{
    [TestClass]
    public class ContactUnitTest
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
